describe("MAN", function () {
    describe("getQueryVariable()", function () {
        var fakeWindow;

        beforeEach(function () {
            fakeWindow = { location: { search: "?q=searchedValue&df=280010|290010|447|1100" }, unescape: function () { } };
        });

        it("should return null when requested parameter is not present in url", function () {
            var value = MAN.getQueryVariable("parametername", false, fakeWindow);

            expect(value).toBe(null);
        });

        it("should return null when no parameter is present in url", function () {
            fakeWindow.location.search = "";

            var value = MAN.getQueryVariable("parametername", false, fakeWindow);

            expect(value).toBe(null);
        });

        it("should return value when requested parameter is present in url", function () {
            var value = MAN.getQueryVariable("q", false, fakeWindow);
            expect(value).toBe("searchedValue");

            value = MAN.getQueryVariable("df", false, fakeWindow);
            expect(value).toBe("280010|290010|447|1100");
        });

        describe("window.unescape", function () {
            /* decodeURIComponent and window.unescape will in some cases return different results, 
            see example from http://www.w3schools.com/jsref/jsref_decodeuricomponent.asp
            "st%C3%A5le" will return "ståle" and "stÃ¥le" respectively               
            */
            beforeEach(function () {
                spyOn(fakeWindow, "unescape");
            });
            afterEach(function () {
                fakeWindow.unescape.reset();
            });
            
            it("should be used when requested", function () {
                var useUnEscape = true;
				var value = MAN.getQueryVariable("q", useUnEscape, fakeWindow);
                expect(fakeWindow.unescape).toHaveBeenCalled();
            });

            it("should not be used when not requested", function () {
                var useUnEscape = false;
				var value = MAN.getQueryVariable("q", useUnEscape, fakeWindow);
                expect(fakeWindow.unescape).not.toHaveBeenCalled();
            });
        });
    });
});