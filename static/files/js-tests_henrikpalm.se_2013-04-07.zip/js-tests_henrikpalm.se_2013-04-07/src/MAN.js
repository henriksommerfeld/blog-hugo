// MAN = My Abbreviated Namespace
var MAN = MAN || {}

MAN.getQueryVariable = function (variable, useUnescape, optionalFakeWindow) {
    var windowInstance = optionalFakeWindow || window;
    var query = windowInstance.location.search.substring(1);
    var vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split('=');
        if (decodeURIComponent(pair[0]) == variable) {
            if (useUnescape)
                return windowInstance.unescape(pair[1]);
            return decodeURIComponent(pair[1]);
        }
    }
    return null;
};

 //MAN.getQueryVariable = function(variable, unescape) {
 //    var query = window.location.search.substring(1);
 //    var vars = query.split('&');
 //    for (var i = 0; i < vars.length; i++) {
 //        var pair = vars[i].split('=');
 //        if (decodeURIComponent(pair[0]) == variable) {
 //            if (unescape)
 //                return unescape(pair[1]);
 //            return decodeURIComponent(pair[1]);
 //        }
 //    }
 //    return null;
 //};