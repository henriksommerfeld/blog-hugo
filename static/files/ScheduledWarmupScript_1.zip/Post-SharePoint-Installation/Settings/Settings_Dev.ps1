Write-Host "Setting Dev environment Properties"
$EnvWarmupUrls = @("http://ourgreatservicedev.ourcompany.com/Pages/default.aspx", 
                   "http://ourgreatservicedev-edit.ourcompany.com/Pages/default.aspx")
$EnvWarmupJobAccount = "NT AUTHORITY\NETWORKSERVICE"
$EnvWarmupScriptPath = "C:\TFS\{0}\Main\Scripts\Post-SharePoint-Installation\Warmup.ps1" -F [Environment]::UserName