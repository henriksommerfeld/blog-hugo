Write-Host "Setting Prod environment Properties"
$EnvWarmupUrls = @("http://ourgreatservice.ourcompany.com/Pages/default.aspx", 
                   "http://ourgreatservice-edit.ourcompany.com/Pages/default.aspx")
$EnvWarmupJobAccount = "NT AUTHORITY\NETWORKSERVICE"
$EnvWarmupScriptPath = "C:\Scheduled scripts\Warmup.ps1"