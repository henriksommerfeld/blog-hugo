$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$HelperScriptsPath = $ScriptPath + "\Helpers"

Clear-Host

# Check arguments, otherwise report argument error ----------------------------
if (!($args.count -eq 1)) 
{
   Write-Host -foregroundcolor red "Must specify environment : dev|inttest|at|prod "
   Write-Host 
   return $false
}
else
{
    $targetEnv = $args[0]
	if (!($targetEnv -eq "dev" -or $targetEnv -eq "inttest" -or $targetEnv -eq "at" -or $targetEnv -eq "prod") )
	{
	   Write-Host -foregroundcolor red "Invalid argument for environment:" $targetEnv
	   Write-Host -foregroundcolor red "Possible values: dev|inttest|at|prod" 
	   Write-Host 
	   return $false
	}
	$tmpPath = $ScriptPath + "\Settings\Settings_" + $targetEnv + ".ps1"
    if (!(Test-Path $tmpPath))
    {
	   Write-Host -foregroundcolor red "Specified settings file '$tmpPath' does not exists."
	   Write-Host 
       return $false
    }
		
	$SettingsFilepath = $tmpPath
    Write-Host -foregroundcolor yellow "# Retrieving local settings from" $SettingsFilepath
	. $SettingsFilepath
}
# -----------------------------------------------------------------------------

# Assert Admin Privileges -----------------------------------------------------
$helperSecurityScript = $HelperScriptsPath + "\Security.ps1"
if (!(Test-Path $helperSecurityScript))
{
	Write-Host "Specified file '$helperSecurityScript' does not exists." -ForegroundColor Red
	Write-Host 
    return $false
}

Import-Module $helperSecurityScript

if(-not (Test-AdminPrivileges))
{
    Write-Host "You are not currently running with administrative privileges.  Please re-start PowerShell as an administrator." -ForegroundColor Red
	Write-Host
    return $false;
}
# -----------------------------------------------------------------------------

return $true