﻿$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$dependenciesLoaded = . $ScriptPath\LoadDependencies.ps1 $args
if (!$dependenciesLoaded) { exit; }

if (!(Test-Path $EnvWarmupScriptPath))
{
	Write-Host -ForegroundColor Red "Specified file '$EnvWarmupScriptPath' does not exist."
	exit
}

try {
	<#	Since the argument passed to SCHTASKS /TR (our $command variable) 
	suffers from Windows file path length limitation, we'll save the URLs we 
	want to hit in a text file and load them from there. #>
	$warmUpScriptFolder = Split-Path -Parent $EnvWarmupScriptPath
	$urlsFile = "{0}\URLsToWarmUp.txt" -F $warmUpScriptFolder
	$EnvWarmupUrls > $urlsFile

	<# To support file paths with spaces and such and at the same time avoid the need of getting 
	a PHD in escape characters, we'll compose a PowerShell script file on the fly that can be executed 
	as a scheduled task without parameters. #>
	$composedScriptFile = "{0}\WarmUpComposed.ps1" -F $warmUpScriptFolder
	$composedScriptFileContent = "Get-Content '{0}' | . '{1}'" -F $urlsFile, $EnvWarmupScriptPath
	$composedScriptFileContent > $composedScriptFile

	$command = "powershell -NoLogo -NonInteractive -WindowStyle Hidden -File '{0}'" -F $composedScriptFile
	$trigger = "*[System[Provider[@Name='Microsoft-Windows-WAS'] and ((EventID &gt;= 5074 and EventID &lt;= 5081) or EventID=5117 or EventID=5186)]]"
	$jobName = "Our Great Service IIS Warmup"
}
catch { throw; }

"Deleting previously existing job named '{0}'..." -F $jobName
SCHTASKS /Delete /TN $jobName /F

"Creating job named '{0}'..." -F $jobName
SCHTASKS /Create /TN $jobName /RU $EnvWarmupJobAccount /RP /TR $command /SC ONEVENT /EC System /MO $trigger